import os
import time,datetime
import random
import keyboard
from threading import Thread
import json
from pathlib import Path

def buy(index):
    global hero, SHOP_CONTENT
    item = SHOP_CONTENT[index]
    if item:
        for i in range(len(hero.inventory_list)):
            if hero.inventory_list[i]['type'] == item['type']:
                if hero.gold>=item['price']:
                    hero.gold -= item['price']
                    hero.inventory_list[i] = item
                    if item['action'] == 'add':
                        setattr(hero, item['effect'][0], getattr(hero, item['effect'][0])+item['effect'][1])
                    elif item['action'] == 'replace':
                        setattr(hero, item['effect'][0], item['effect'][1])
                    SHOP_CONTENT[index] = ''
def buy_button():
    global hero
    keys = ['!', '@', '#', '$'] if os.name=='nt' else ['1','2','3','4']
    while True:
        for key in keys:
            if keyboard.is_pressed(key):
                buy(keys.index(key))
def interact():
    global hero
    while True:
        if keyboard.is_pressed('e'):
            if hero.facing_right:
                interaction_x = hero.position[0]+1
            else:
                interaction_x = hero.position[0]-1
            for e in EVENTS:
                if e.position[1]==hero.position[1] and e.position[0]==interaction_x:
                    e.interaction(hero)

def clear_screen():
    os.system('cls' if os.name=='nt' else 'clear')

class Event:
    def __init__(self, kind, ):
        global hero
        self.kind = kind
        if self.kind == 'enemy':
            global ENEMIES
            enemy = random.choice(ENEMIES)
            self.damage = enemy['damage']*hero.lvl()
            self.bounty = enemy['gold']*hero.lvl()
            self.hp = enemy['hp']*hero.lvl()
            self.species = enemy['species']
            self.name = f"{self.species}|{self.hp}HP"
            self.model = enemy['model']
            self.last_moved = datetime.datetime.now()
            self.last_attacked = 0
            self.moves = True
            self.attack_cd = datetime.timedelta(seconds = 1/enemy['attack_speed'])
            self.move_cd = datetime.timedelta(seconds = 1/enemy['speed'])
            self.interaction_point = 1
        elif self.kind == 'gold':
            self.moves = False
            self.quantity = random.randint(1,10)*hero.lvl()
            self.name = f'Gold({self.quantity})'
            self.model = '*'
            self.interaction_point = 0
    def action(self, hero):
        global EVENTS
        if self.kind == 'gold':
            pass
        elif self.kind == 'enemy':
            if not self.last_attacked:
                self.last_attacked = datetime.datetime.now()
            if datetime.datetime.now()-self.last_attacked>self.attack_cd:
                hero.hp = max(0, hero.hp-max(0, self.damage-hero.armor))
                self.last_attacked = datetime.datetime.now()
    def interaction(self, hero):
        global EVENTS
        if self.kind == 'enemy':
            if datetime.datetime.now()-hero.last_attacked>hero.attack_cd:
                self.hp -= hero.attack
                hero.last_attacked = datetime.datetime.now()
                if self.hp <= 0:
                    EVENTS.remove(self)
                    hero.gold += self.bounty
                self.name = f"{self.species}|{self.hp}HP"
        elif self.kind == 'gold':
            hero.gold += self.quantity
            EVENTS.remove(self) 
    def move(self):
        global lost
        if datetime.datetime.now()-self.last_moved>self.move_cd and self.position[0]>0:
            self.position[0]-=1
            self.last_moved = datetime.datetime.now()
            if self.position[0] == 0:
                lost = 0        
class Character:
    def __init__(self, name="Hero", hp=100, gold=0, inventory=[{},{},{},{}], forward_model='R', backward_model='Я'):
        self.name = name
        self.hp = hp
        self.gold = gold
        self.inventory_list = inventory
        self.facing_right = True
        self.start = datetime.datetime.now()
        self.position = [0,0]
        self.forward_model = forward_model
        self.backward_model = backward_model
        self.armor = 0
        self.move_cd = 0.25
        self.attack_cd = datetime.timedelta(seconds=1)
        self.attack = 1
        self.last_attacked = datetime.datetime.now()
    def model(self):
        return self.forward_model if self.facing_right else self.backward_model
    def lvl(self):
        global LEVEL
        return max(1,LEVEL)
    def update_profile(self, profile=None):
        if not hasattr(self, 'profile'):
            if not profile:
                print(f"No profile block found for the character.")
                exit()
            else:
                self.profile = profile
        self.stopwatch = [(datetime.datetime.now()-self.start).seconds//3600,(datetime.datetime.now()-self.start).seconds%3600//60,(datetime.datetime.now()-self.start).seconds%60]
        self.profile.content = [f'Name: {self.name}', f'HP: {self.hp}', f'Gold: {self.gold}', f'LVL: {hero.lvl()}',f'Time: {str(self.stopwatch[0]).zfill(2)}:{str(self.stopwatch[1]).zfill(2)}:{str(self.stopwatch[2]).zfill(2)}']
        self.profile.update_image()
    def update_inventory(self, inventory=None):
        if not hasattr(self, 'inventory'):
            if not inventory:
                print(f"No inventory block found for the character.")
                exit()
            else:
                self.inventory = inventory
        content = []
        types = {0: 'Weapon', 1: 'Armor', 2: 'Potion', 3: 'Boots'}
        for i, item in enumerate(self.inventory_list):
            if not item:
                item['name'] = 'None'
                item['type'] = types[i]
            content.append(f"{i+1}. {item['name']}")
        self.inventory.content = content
        self.inventory.update_image()
class InterfaceBlock:
    def __init__(self, heading, placement, content="", x_border='-', y_border='|'):
        self.heading = heading
        for axis in range(len(placement)):
            for ind in range(len(placement[axis])):
                c = placement[axis][ind]
                if type(c) == str:
                    percent = int(c[:c.rfind('%')])
                    if axis == 0:
                        placement[0][ind] = int(os.get_terminal_size().columns/100*percent)
                        Thread(target=self.update_width, args=(ind, percent)).start()
                    elif axis == 1:
                        placement[1][ind] = int(os.get_terminal_size().lines/100*percent)
                        Thread(target=self.update_height, args=(ind, percent)).start()
        self.width = placement[0][1]-placement[0][0]
        self.height = placement[1][1]-placement[1][0]
        self.start = [placement[0][0], placement[1][0]]
        self.end = [placement[0][1], placement[1][1]]
        self.content = content
        self.x_border = x_border
        self.y_border = y_border
    def update_width(self, index, percent):
        time.sleep(1)
        while True:
            if index==1:
                self.end[0] = int(os.get_terminal_size().columns/100*percent)
            elif index==0:
                self.start[0] = int(os.get_terminal_size().columns/100*percent)
            self.width = self.end[0]-self.start[0]
            self.update_image()
            time.sleep(0.1)
    def update_height(self, index, percent):
        time.sleep(1)
        while True:
            if index==1:
                self.end[1] = int(os.get_terminal_size().lines/100*percent)
            elif index==0:
                self.start[1] = int(os.get_terminal_size().lines/100*percent)
            self.width = self.end[1]-self.start[1]
            time.sleep(0.1)
    def update_content(self, content):
        self.content = content
        self.update_image()
    def update_image(self):
        image = {}
        heading_border = (self.width-len(self.heading))
        if heading_border%2:
            self.heading += ' '
        heading_border //= 2 
        image[self.start[1]]=f"+{self.x_border*(heading_border-1)}{self.heading}{self.x_border*(heading_border-1)}+"
        line_width = self.width-4
        if type(self.content)==str:
            lines = [self.y_border+' '+' '*line_width+' '+self.y_border]
            i = 0
            while i < len(self.content):
                while len(self.content)-i < line_width:
                    self.content+=' '
                line = self.y_border+' '+self.content[i:i+line_width]+' '+self.y_border
                lines.append(line)
                i += line_width+1
            for i, l in enumerate(lines):
                image[self.start[1]+i+1] = l
        elif type(self.content)==list:
            image[self.start[1]+1] = self.y_border+' '+' '*line_width+' '+self.y_border
            for i, l in enumerate(self.content):
                while len(l)<line_width:
                    l+=' '
                while len(l) > line_width:
                    line_width = self.width-4
                    #print(self.width)
                    #print(len(l), line_width)
                    print(f"Not enough width set for block '{self.heading.strip()}'. Please adjust your terminal window.")
                    time.sleep(5)
                    clear_screen()
                    #print(l)
                image[self.start[1]+i+2] = self.y_border+' '+l+' '+self.y_border
        while len(image) < self.height-1:
            image[self.start[1]+len(image)] = self.y_border+' '+' '*line_width+' '+self.y_border
        if len(image) > self.height-1:
            print(f"Not enough height set for block '{self.heading.strip()}'")
            exit()
        image[self.start[1]+self.height-1] = f"+{self.x_border*(self.width-2)}+"
        self.image = image

def generate_event(kind, hero_position, lines, line_width, events_positions):
    event = Event(kind)
    possible_Y = [*range(lines)]
    while possible_Y:
        line = random.choice(possible_Y)
        if line == hero_position[1]:
            possible_X = [*range(max(hero_position[0]+3, line_width//2), line_width)]
        else:
            possible_X = [*range(line_width//2, line_width)]
        while possible_X:
            column = random.choice(possible_X)
            if [column, line] not in events_positions and [column, line] != hero_position:
                event.position = [column, line]
                return event
            else:
                possible_X.remove(column)
        possible_Y.remove(line)
def generate_events(hero_position, quantity, lines, line_width):
    global EVENTS
    for i in range(quantity):
        event = generate_event(random.choice(['enemy', 'gold']), hero_position, lines, line_width, [e.position for e in EVENTS])
        if event:
            EVENTS.append(event)
def generate_game_content(gameBlock):
    global EVENTS, LEVEL
    lines = (gameBlock.height-4)//2
    line_width = gameBlock.width-4
    content = []
    if not EVENTS:
        generate_events(hero.position, EVENTS_PER_LVL*min(max(1,hero.lvl()), MAX_EVENTS), lines, line_width)
        LEVEL += 1
    for ind in range(lines):
        events_copy = EVENTS.copy()
        line = '_'*line_width
        heading = [' ']*line_width
        for e in sorted(events_copy, key=lambda event: int(event.moves)):
            if e.position[1]==ind:
                i = e.position[0]
                for ch in e.name:
                    if i<len(heading):
                        if heading[i]!=' ':
                            for occup in range(e.position[0], i):
                                heading[occup] = ' '
                            break
                        heading[i] = ch
                        i+=1
                if hero.position[1]==e.position[1] and abs(hero.position[0]-e.position[0])==e.interaction_point:
                    e.action(hero)
                elif e.moves and e.position[0]-1 not in [event.position[0] for event in EVENTS if event.position[1]==e.position[1] and event.moves]:
                    e.move()
                line = line[:e.position[0]]+e.model+line[e.position[0]+1:]
        if ind == hero.position[1]:
            i = hero.position[0]
            for ch in hero.name:
                if i<len(heading):
                    if heading[i]!=' ':
                        for occup in range(hero.position[0], i):
                            heading[occup] = ' '
                        break
                    heading[i] = ch
                    i+=1
            line = line[:hero.position[0]]+hero.model()+line[hero.position[0]+1:]
        heading = ''.join(heading)
        content.append(heading)
        content.append(line)
    return content
def generate_shop_content():
    global SHOP_CONTENT, SHOP_LAST_UPDATE
    if not SHOP_CONTENT or datetime.datetime.now()-SHOP_LAST_UPDATE>=datetime.timedelta(minutes=1):
        SHOP_CONTENT = []
        items = [random.choice(ITEMS) for time in range(3)]+[ITEMS[0]]
        for i in items:
            content_item = {}
            points = i['basic_points']*hero.lvl()
            content_item['description'] = i['description'].format(points)
            content_item['name'] = i['name'].format(hero.lvl())
            content_item['effect'] = [i['effect'], points]
            content_item['price'] = i['basic_price'] * hero.lvl()
            content_item['type'] = i['type']
            content_item['action'] = i['action']
            SHOP_CONTENT.append(content_item)
        SHOP_LAST_UPDATE = datetime.datetime.now()
    content = []
    for i in range(len(SHOP_CONTENT)):
        item = SHOP_CONTENT[i]
        if not item:
            content.append(f"{i+1}.")
            continue
        line = f"{i+1}. {item['name']} ({item['description']}) - {item['price']} GOLD"
        content.append(line)
    time = (datetime.timedelta(minutes=1)-(datetime.datetime.now()-SHOP_LAST_UPDATE)).seconds
    content.append(f"Before Update: {str(time//60).zfill(2)}:{str(time%60).zfill(2)}")
    return content
def global_image(blocks):
    image = {i:'' for i in range(os.get_terminal_size().lines-1)}
    for ind in range(os.get_terminal_size().lines-1):
        line = {}
        for block in blocks:
            if block.start[1]<=ind<block.end[1]:
                for i in range(len(block.image[ind])):
                    line[block.start[0]+i] = block.image[ind][i]
        if line:
            for i in range(min(line), max(line)):
                if i not in line:
                    line[i] = ' '
        image[ind] = ''.join(line[s] for s in sorted(line))
    return '\n'.join(list(image.values()))

ENEMIES = json.load(open(Path(__file__).resolve().parent / 'enemies.json'))
ITEMS = json.load(open(Path(__file__).resolve().parent / 'items.json'))
EVENTS = []
LEVEL = 0
EVENTS_PER_LVL = 4
MAX_EVENTS = 15
# Start screen
start_dialogue = InterfaceBlock('Controls', [[0, '100%'], [0, 8]])
start_dialogue.update_content(["1. Move with W, A, S, D", "2. Buy from the shop with 1, 2, 3, 4", "3. Interact / Attack with E", "4. Press Space to close this window."])
gi = global_image([start_dialogue])
print(gi)
keyboard.wait('space')
clear_screen()

name = input("Enter your name: ")
hero = Character(name if name else os.getlogin())

# Initializing all the interface blocks and registering them
profile = InterfaceBlock('Profile', [[0,'20%'],[0,8]])
inventory = InterfaceBlock('Inventory', [['20%', '40%'], [0, 8]])
shop = InterfaceBlock('Shop', [['40%', '100%'], [0, 8]])
game = InterfaceBlock('Gameplay', [[0, '100%'], [8, 25]])
blocks = [profile, inventory, shop, game, ]

hero.update_profile(profile)
hero.update_inventory(inventory)


SHOP_CONTENT = [

]
SHOP_LAST_UPDATE = hero.start
#dialogue.update_content("")
while os.get_terminal_size().lines<max(blocks, key=lambda x: x.end[1]).end[1]:
    clear_screen()
    print("Terminal is too small to display interface.")
    time.sleep(1)
def move_up():
    global hero
    while True:
        if keyboard.is_pressed('w') or keyboard.is_pressed('up'):
            if 0 < hero.position[1] and hero.position[0] not in [e.position[0] for e in EVENTS if e.position[1]+1==hero.position[1]]:
                hero.position[1] -= 1
                time.sleep(0.25)
def move_down():
    lines = (game.height-4)//2
    global hero
    while True:
        if keyboard.is_pressed('s') or keyboard.is_pressed('down'):
            if hero.position[1] < lines-1 and hero.position[0] not in [e.position[0] for e in EVENTS if e.position[1]-1==hero.position[1]]:
                hero.position[1] += 1
                time.sleep(0.25)
def move_left():
    global hero
    while True:
        if keyboard.is_pressed('a') or keyboard.is_pressed('left'):
            if 0 < hero.position[0] and hero.position[0]-1 not in [e.position[0] for e in EVENTS if e.position[1]==hero.position[1]]:
                hero.position[0] -= 1
            hero.facing_right = False
            time.sleep(hero.move_cd)
def move_right():
    line_width = game.width-4
    global hero
    while True:
        if keyboard.is_pressed('d') or keyboard.is_pressed('right'):
            if hero.position[0] < line_width-1 and hero.position[0]+1 not in [e.position[0] for e in EVENTS if e.position[1]==hero.position[1]]:
                hero.position[0] += 1
            hero.facing_right = True
            time.sleep(hero.move_cd)
THREADS = [Thread(target=move_up), Thread(target=move_down), Thread(target=move_left), Thread(target=move_right), Thread(target=interact), Thread(target=buy_button)]
for t in THREADS:
    t.start()

while True:
    if hero.hp>0 and len([event for event in EVENTS if event.position[0]==0])==0:
        game_content = generate_game_content(game)
        hero.update_profile()
        hero.update_inventory()
        shop_content = generate_shop_content()
        shop.update_content(shop_content)
    else:
        game_content = "You're dead, bozo."
    game.update_content(game_content)
    gi = global_image(blocks)
    clear_screen()
    print(gi)
    time.sleep(0.25)